package com.fin.tsfapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TsfappApplicationTests {

	@Test
	void contextLoads() {
	}

}
