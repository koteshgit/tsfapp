package com.fin.tsfapp.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.fin.tsfapp.dto.FilterCriteriaDto;
import com.fin.tsfapp.dto.TransactionDto;
import com.fin.tsfapp.entity.Account;
import com.fin.tsfapp.entity.TsfTransaction;
import com.fin.tsfapp.enums.TsfappEnums;
import com.fin.tsfapp.enums.TsfappEnums.TransactionType;
import com.fin.tsfapp.repository.TransactionRepository;

class TransactionServiceTest {

    @Mock
    private TransactionRepository transactionRepository;

    @Mock
    private AccountService accountService;

    @InjectMocks
    private TransactionService transactionService;

    private Account account;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        account = new Account();
        account.setId(1L);
        account.setAccountHolderName("M Paul");
        account.setBalance(1000.0);
    }

    @Test
    void testMakeTransaction_Success() throws Exception {
        TransactionDto transactionDto = new TransactionDto(100.0, TsfappEnums.TransactionType.CREDIT);
        when(accountService.getAccountById(1L)).thenReturn(account);

        transactionService.makeTransaction(1L, transactionDto);

        assertEquals(1100.0, account.getBalance());
        verify(transactionRepository, times(1)).save(any(TsfTransaction.class));
    }

    @Test
    void testMakeTransaction_InsufficientFunds() {
        TransactionDto transactionDto = new TransactionDto(1100.0, TransactionType.DEBIT);

        when(accountService.getAccountById(1L)).thenReturn(account);

        Exception exception = assertThrows(Exception.class, () -> {
            transactionService.makeTransaction(1L, transactionDto);
        });

        assertEquals("Insufficient funds", exception.getMessage());
    }

    @Test
    void testFraudDetection_WithdrawOverLimit() {
        TransactionDto transactionDto = new TransactionDto(15000.0, TransactionType.DEBIT);

        when(accountService.getAccountById(1L)).thenReturn(account);

        Exception exception = assertThrows(Exception.class, () -> {
            transactionService.makeTransaction(1L, transactionDto);
        });

        assertEquals("Fraud detection: Cannot withdraw more than $10,000 in a day", exception.getMessage());
    }

    @Test
    void testGetTransactionHistory() {
        TsfTransaction transaction1 = new TsfTransaction();
        transaction1.setId(1L);
        transaction1.setAmount(100.0);
        transaction1.setType(TransactionType.CREDIT);
        transaction1.setTransactionDate(LocalDateTime.now());

        TsfTransaction transaction2 = new TsfTransaction();
        transaction2.setId(2L);
        transaction2.setAmount(200.0);
        transaction2.setType(TransactionType.DEBIT);
        transaction2.setTransactionDate(LocalDateTime.now());
        
        LocalDateTime startDate = LocalDateTime.now();
        LocalDateTime endDate = LocalDateTime.of(2014, 
                Month.OCTOBER, 10, 10, 30, 40);
        FilterCriteriaDto filterCriteriaDto = new FilterCriteriaDto(1L, 1, 10, "IN", startDate, endDate);

        Pageable pageable = PageRequest.of(0, 10);
        Page<TsfTransaction> page = new PageImpl<>(Arrays.asList(transaction1, transaction2), pageable, 2);

        when(transactionRepository.findByAccountIdAndTypeAndTransactionDateBetweenPageable(1L, null, null, null, pageable)).thenReturn(page);

        Page<TsfTransaction> transactionHistory = transactionService.getTransactionHistory(filterCriteriaDto);

        assertNotNull(transactionHistory);
        assertEquals(2, transactionHistory.getTotalElements());
    }
}

