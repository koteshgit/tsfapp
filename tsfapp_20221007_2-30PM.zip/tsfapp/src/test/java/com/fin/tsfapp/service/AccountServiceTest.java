package com.fin.tsfapp.service;

import com.fin.tsfapp.dto.AccountDto;
import com.fin.tsfapp.entity.Account;
import com.fin.tsfapp.enums.TsfappEnums.AccountStatus;
import com.fin.tsfapp.repository.AccountRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AccountServiceTest {

	@Mock
	private AccountRepository accountRepository;

	@InjectMocks
	private AccountService accountService;

	String userName1;
	String userName2;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		userName1 = "VR Kotesh";
		userName2 = "K Ramesh";
	}

	@Test
	void testCreateAccount() {
		AccountDto accountDto = new AccountDto(userName1, 1000.0);
		Account account = new Account();
		account.setId(1L);
		account.setAccountHolderName(userName1);
		account.setBalance(1000.0);

		when(accountRepository.save(any(Account.class))).thenReturn(account);

		Account createdAccount = accountService.createAccount(accountDto);

		assertNotNull(createdAccount);
		assertEquals(userName1, createdAccount.getAccountHolderName());
		assertEquals(1000.0, createdAccount.getBalance());
	}

	@Test
	void testGetAccountById() {
		Account account = new Account();
		account.setId(1L);
		account.setAccountHolderName(userName1);
		account.setBalance(1000.0);

		when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

		Account foundAccount = accountService.getAccountById(1L);

		assertNotNull(foundAccount);
		assertEquals(userName1, foundAccount.getAccountHolderName());
		assertEquals(1000.0, foundAccount.getBalance());
	}

	@Test
	void testUpdateAccount() {
		AccountDto accountDTO = new AccountDto(userName2, 2000.0);
		Account existingAccount = new Account();
		existingAccount.setId(1L);
		existingAccount.setAccountHolderName(userName2);
		existingAccount.setBalance(1000.0);

		when(accountRepository.findById(1L)).thenReturn(Optional.of(existingAccount));
		when(accountRepository.save(any(Account.class))).thenReturn(existingAccount);

		Account updatedAccount = accountService.updateAccount(1L, accountDTO);

		assertEquals(userName2, updatedAccount.getAccountHolderName());
	}

	@Test
	void testSuspendAccount() {
		Account account = new Account();
		account.setId(1L);
		account.setAccountHolderName(userName1);
		account.setBalance(1000.0);

		when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

		accountService.suspendAccount(1L);

		assertEquals(AccountStatus.SUSPENDED, account.getStatus());
		verify(accountRepository, times(1)).save(account);
	}
}
