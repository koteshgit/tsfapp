package com.fin.tsfapp.service.impl;

import com.fin.tsfapp.dto.AccountDto;
import com.fin.tsfapp.entity.Account;
import com.fin.tsfapp.enums.TsfappEnums.AccountStatus;
import com.fin.tsfapp.repository.AccountRepository;
import com.fin.tsfapp.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountRepository accountRepository;

	public Account createAccount(AccountDto accountDto) {
		Account account = new Account();
		account.setAccountHolderName(accountDto.getAccountHolderName());
		account.setBalance(accountDto.getInitialBalance());
		return accountRepository.save(account);
	}

	public Account getAccountById(Long accountId) {
		return accountRepository.findById(accountId).orElseThrow(() -> new RuntimeException("Account not found"));
	}

	public Account updateAccount(Long accountId, AccountDto accountDto) {
		Account account = getAccountById(accountId);
		account.setAccountHolderName(accountDto.getAccountHolderName());
		return accountRepository.save(account);
	}

	public void suspendAccount(Long accountId) {
		Account account = getAccountById(accountId);
		account.setStatus(AccountStatus.SUSPENDED);
		accountRepository.save(account);
	}

	public void saveAccount(Account account) {
		accountRepository.save(account);
	}
}