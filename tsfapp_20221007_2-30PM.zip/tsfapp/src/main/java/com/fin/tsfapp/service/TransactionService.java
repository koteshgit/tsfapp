package com.fin.tsfapp.service;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.fin.tsfapp.dto.FilterCriteriaDto;
import com.fin.tsfapp.dto.TransactionDto;
import com.fin.tsfapp.entity.TsfTransaction;

@Service
public interface TransactionService {

	void makeTransaction(long accountId, TransactionDto transactionDto) throws Exception;

	Page<TsfTransaction> getTransactionHistory(FilterCriteriaDto filterCriteriaDto);

	boolean detectFraud(Long accountId, Double transactionAmount);
} 
