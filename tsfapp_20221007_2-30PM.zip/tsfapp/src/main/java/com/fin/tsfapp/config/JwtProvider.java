package com.fin.tsfapp.config;

import java.util.Base64;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtProvider {

	@Value("${tsfapp.jwtSecret}")
	private static String jwtSecret = "tsfapp";

	@Value("${tsfapp.jwtExpiration}")
	private static int jwtExpiration = 5 * 60 * 60;

	public static String generateJwtToken(String userName) {
		String encodedJwtSecret = Base64.getEncoder().encodeToString(jwtSecret.getBytes());
		try {
			return Jwts.builder().setSubject((userName)).setIssuedAt(new Date())
					.setExpiration(new Date((new Date()).getTime() + jwtExpiration * 1000))
					.signWith(SignatureAlgorithm.HS256, encodedJwtSecret).compact();
		} catch (Exception e) {
			Throwable cause = e.getCause();
			cause.printStackTrace();
			return null;
		}
	}

	public boolean validateJwtToken(String authToken) {
		boolean isValid = false;
		Jwts.parser().setSigningKey(jwtSecret.getBytes()).parseClaimsJws(authToken);
		isValid = true;
		return isValid;
	}

	public String getUserNameFromJwtToken(String token) {
		return Jwts.parser().setSigningKey(jwtSecret.getBytes()).parseClaimsJws(token).getBody().getSubject();
	}

	public String getEmailFromJwtToken(String token) {
		return Jwts.parser().setSigningKey(jwtSecret).parseClaimsJws(token).getBody().getSubject();
	}
}