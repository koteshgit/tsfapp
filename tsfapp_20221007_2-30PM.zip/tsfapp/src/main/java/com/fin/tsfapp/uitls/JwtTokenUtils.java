package com.fin.tsfapp.uitls;

import com.fin.tsfapp.config.JwtProvider;

public class JwtTokenUtils {
	static JwtProvider jwtProvider = new JwtProvider();
	
	public static void main(String[] args) {
		String JwtToken ="";
		try {
			try {
				String userName = "TestUser";
				JwtToken = JwtProvider.generateJwtToken(userName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("Jwt Token - "+ JwtToken);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
