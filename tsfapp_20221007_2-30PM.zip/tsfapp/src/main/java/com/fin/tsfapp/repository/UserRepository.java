package com.fin.tsfapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fin.tsfapp.entity.Account;
import com.fin.tsfapp.entity.User;

@Repository
public interface UserRepository extends JpaRepository<Account, Long>{
	@Query(name = "User.getUserByUserName")
    User findByUserName(String userName);
}
