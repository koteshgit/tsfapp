package com.fin.tsfapp.dto;

public class AccountDto {
    private String accountHolderName;
    private Double initialBalance;

    public AccountDto() {}

    public AccountDto(String accountHolderName, Double initialBalance) {
        this.accountHolderName = accountHolderName;
        this.initialBalance = initialBalance;
    }

    public String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public Double getInitialBalance() {
        return initialBalance;
    }

    public void setInitialBalance(Double initialBalance) {
        this.initialBalance = initialBalance;
    }
}
