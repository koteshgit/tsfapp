package com.fin.tsfapp.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fin.tsfapp.dto.ErrorDetails;
import com.fin.tsfapp.entity.User;
import com.fin.tsfapp.service.UserDetailsService;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtAuthTokenFilter extends OncePerRequestFilter {

	private static JwtProvider tokenProvider = new JwtProvider();

	@Autowired
	private UserDetailsService userDetailsService;

	private static final Logger logger = LoggerFactory.getLogger(JwtAuthTokenFilter.class);
	HttpStatus httpStatus = HttpStatus.OK;
	String message = "";
	String errorMessage = "";
	List<String> noTokenPathList = new ArrayList<String>();
	static String userName = "VE Kamesh";

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		try {
//			String path = request.getRequestURI();
//			String cPath = path.substring(path.lastIndexOf("/"));
				String jwt = getJwt(request);
				if (jwt != null && tokenProvider.validateJwtToken(jwt)) {
					String username = tokenProvider.getUserNameFromJwtToken(jwt);
					// String email = tokenProvider.getEmailFromJwtToken(jwt);
					User user = userDetailsService.findByUserName(username);
					logger.info(user.getUserName());
					if (user == null || user.getUserName().isEmpty()) {
						logger.error("Can not set user reason ->userNotFound");
					}
				} else {
					logger.error("JWT Token NOT Available Please provide token");
					response.setStatus(HttpStatus.UNAUTHORIZED.value());
					ErrorDetails errorDetails = new ErrorDetails(HttpStatus.UNAUTHORIZED.getReasonPhrase(),
							HttpStatus.UNAUTHORIZED.value(), "Token is mandatory", "Error is: " + "Token is required");

					response.setContentType("application/json");
					new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
					return;
				}
//			}
		} catch (SignatureException se) {
			logger.info("Signature invalid. Error is: " + se.getLocalizedMessage());
			ErrorDetails errorDetails = new ErrorDetails(HttpStatus.FORBIDDEN.getReasonPhrase(),
					HttpStatus.FORBIDDEN.value(), se.getMessage(),
					"Signature invalid. Error is: " + se.getLocalizedMessage());

			response.setContentType("application/json");
			new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
			return;
		} catch (IllegalArgumentException e) {
			logger.info("Unable to get JWT Token");
			ErrorDetails errorDetails = new ErrorDetails(HttpStatus.FORBIDDEN.getReasonPhrase(),
					HttpStatus.FORBIDDEN.value(), e.getMessage(), "Unable to get JWT Token");

			response.setContentType("application/json");
			new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
			return;
		} catch (ExpiredJwtException e) {
			logger.error("JWT Token has expired: Error: " + e.getLocalizedMessage());
			ErrorDetails errorDetails = new ErrorDetails("ExpiredJwtException", HttpStatus.FORBIDDEN.value(),
					e.getMessage(), "Please regenarate token. And try Again");

			response.setContentType("application/json");
			new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
			return;
		} catch (MalformedJwtException mfje) {
			logger.error("JWT strings must contain exactly 2 period characters. Found: 1: Error: "
					+ mfje.getLocalizedMessage());
			ErrorDetails errorDetails = new ErrorDetails("MalformedJwtException", HttpStatus.FORBIDDEN.value(),
					mfje.getMessage(), "Please regenarate token. And try Again");
			errorDetails.setStatus(HttpStatus.EXPECTATION_FAILED.value());
			response.setContentType("application/json");
			new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
			return;
		} catch (Exception e) {
			logger.error("Can NOT set user authentication -> Message: {}", e);
			message = "In valid token";
			httpStatus = HttpStatus.UNAUTHORIZED;
			errorMessage = "Token not found";
			logger.info(message);
			ErrorDetails errorDetails = new ErrorDetails("ServletException", HttpStatus.UNAUTHORIZED.value(),
					e.getLocalizedMessage(), "Invalid Auth token");

			response.setContentType("application/json");
			new ObjectMapper().writeValue(response.getOutputStream(), errorDetails);
			return;
		}
		filterChain.doFilter(request, response);
	}

	private String getJwt(HttpServletRequest request) {
		String authHeader = "";

		authHeader = request.getHeader("Authorization");
		if(authHeader == null) {
			authHeader = request.getParameter("Authorization");
		}
//		if(authHeader!=null && authHeader.startsWith("Bearer ")) {
			authHeader = authHeader.substring(7);
//		}

		return authHeader;
	}

//	private void printRequest(HttpServletRequest httpRequest) {
//		System.out.println(" \n\n Headers");
//
//		Enumeration headerNames = httpRequest.getHeaderNames();
//		while (headerNames.hasMoreElements()) {
//			String headerName = (String) headerNames.nextElement();
//			System.out.println(headerName + " = " + httpRequest.getHeader(headerName));
//		}
//
//		System.out.println("\n\nParameters");
//
//		Enumeration params = httpRequest.getParameterNames();
//		while (params.hasMoreElements()) {
//			String paramName = (String) params.nextElement();
//			System.out.println(paramName + " = " + httpRequest.getParameter(paramName));
//		}
//
//		System.out.println("\n\n Row data");
//	}
//	
}
