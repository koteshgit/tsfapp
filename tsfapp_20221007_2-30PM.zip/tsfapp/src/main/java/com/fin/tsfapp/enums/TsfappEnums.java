package com.fin.tsfapp.enums;

public class TsfappEnums {

	public static enum AccountStatus {
	    ACTIVE, SUSPENDED
	}
	
	public static enum TransactionType {
		CREDIT, DEBIT
	}
}
