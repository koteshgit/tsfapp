package com.fin.tsfapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fin.tsfapp.dto.FilterCriteriaDto;
import com.fin.tsfapp.dto.TransactionDto;
import com.fin.tsfapp.entity.TsfTransaction;
import com.fin.tsfapp.service.TransactionService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/transactions")
public class TransactionController {
	@Autowired
	private TransactionService transactionService;

	@PostMapping
	public ResponseEntity<String> makeTransaction(@PathVariable Long accountId,
			@RequestBody TransactionDto transactionDto) {
		try {
			transactionService.makeTransaction(accountId, transactionDto);
			return ResponseEntity.ok("TsfTransaction successful");
		} catch (Exception e) {
			return ResponseEntity.badRequest().body(e.getMessage());
		}
	}

	@GetMapping
	public ResponseEntity<Page<TsfTransaction>> getTransactionHistory(
			@RequestBody FilterCriteriaDto filterCriteriaDto) {
		Page<TsfTransaction> transactions = transactionService.getTransactionHistory(filterCriteriaDto);
		return ResponseEntity.ok(transactions);
	}
}