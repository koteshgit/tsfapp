package com.fin.tsfapp.entity;

import java.time.LocalDateTime;

import com.fin.tsfapp.enums.TsfappEnums.TransactionType;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;

@Entity
@Table(name = "transactions")
@NamedQueries({
    @NamedQuery(name = "Transaction.findByAccountId",
                query = "SELECT t FROM Transaction t WHERE t.account_id = :accountId"),
    @NamedQuery(name = "Transaction.findByAccountIdAndTypeAsList",
                query = "SELECT t FROM Transaction t WHERE t.account_id = :accountId AND t.type = :type"),
    @NamedQuery(name = "Transaction.findByAccountIdAndTypeAsPageable",
    query = "SELECT t FROM Transaction t WHERE t.account_id = :accountId AND t.type = :type"),
    @NamedQuery(name = "Transaction.findByAccountIdAndTransactionDateBetween",
                query = "SELECT t FROM Transaction t WHERE t.account.id = :accountId AND t.transactionDate BETWEEN :startDate AND :endDate"),
    @NamedQuery(name = "Transaction.findByAccountIdAndTypeAndTransactionDateBetween",
                query = "SELECT t FROM Transaction t WHERE t.account_id = :accountId AND t.type = :type AND t.transactionDate BETWEEN :startDate AND :endDate")
})
public class TsfTransaction {
	@EmbeddedId
	@Column(name = "transaction_id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long transactionId;

	@ManyToOne
	@JoinColumn(name = "account_id")
	private Account account;

	private Double amount;

	@Enumerated(EnumType.STRING)
	private TransactionType type;

	private LocalDateTime transactionDate;

	public Long getId() {
		return transactionId;
	}

	public void setId(Long id) {
		this.transactionId = id;
	}
	
	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public TransactionType getType() {
		return type;
	}

	public void setType(TransactionType type) {
		this.type = type;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}
}