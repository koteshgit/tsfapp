package com.fin.tsfapp.dto;

import java.time.LocalDateTime;

import com.fin.tsfapp.enums.TsfappEnums.TransactionType;


public class TransactionDto {
	private Double amount;
	private TransactionType type;
	private LocalDateTime transactionDate;

	public TransactionDto() {
	}

	public TransactionDto(Double amount, TransactionType type) {
		this.amount = amount;
		this.type = type;
		this.transactionDate = LocalDateTime.now();
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public TransactionType getType() {
		return type;
	}

	public void setType(TransactionType type) {
		this.type = type;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}
}
