package com.fin.tsfapp.service;

import org.springframework.stereotype.Service;

import com.fin.tsfapp.dto.AccountDto;
import com.fin.tsfapp.entity.Account;

@Service
public interface AccountService {
	Account createAccount(AccountDto accountDto);
	Account getAccountById(Long accountId);
	Account updateAccount(Long accountId, AccountDto accountDto);
	void suspendAccount(Long accountId);
	void saveAccount(Account account);
}
