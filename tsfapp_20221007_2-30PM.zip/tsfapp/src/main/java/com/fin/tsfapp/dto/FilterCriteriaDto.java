package com.fin.tsfapp.dto;

import java.time.LocalDateTime;

public class FilterCriteriaDto {
	private Long accountId;
	private int page;
	private int size;
	private String type;
	private LocalDateTime startDate;
	private LocalDateTime endDate;
	
	public FilterCriteriaDto() {}
	public FilterCriteriaDto(Long accountId, int page, int size, String type, LocalDateTime startDate,
			LocalDateTime endDate) {
		this.accountId = accountId;
		this.page = page;
		this.size = size;
		this.type = type;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public LocalDateTime getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}
	public LocalDateTime getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}
}
