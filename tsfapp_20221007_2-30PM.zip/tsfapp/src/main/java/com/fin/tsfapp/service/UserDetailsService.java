package com.fin.tsfapp.service;

import org.springframework.stereotype.Service;

import com.fin.tsfapp.entity.User;

@Service
public interface UserDetailsService {
	User findByUserName(String userName);
}
