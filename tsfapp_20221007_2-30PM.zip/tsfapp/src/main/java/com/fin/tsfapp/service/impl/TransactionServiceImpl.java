package com.fin.tsfapp.service.impl;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fin.tsfapp.dto.FilterCriteriaDto;
import com.fin.tsfapp.dto.TransactionDto;
import com.fin.tsfapp.entity.Account;
import com.fin.tsfapp.entity.TsfTransaction;
import com.fin.tsfapp.enums.TsfappEnums;
import com.fin.tsfapp.enums.TsfappEnums.TransactionType;
import com.fin.tsfapp.repository.TransactionRepository;
import com.fin.tsfapp.service.AccountService;
import com.fin.tsfapp.service.TransactionService;

@Service
public class TransactionServiceImpl implements TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;
	@Autowired
	private AccountService accountService;

	@Override
	@Transactional
	public void makeTransaction(long accountId, TransactionDto transactionDto) throws Exception {
		Account account = accountService.getAccountById(accountId);

		if (transactionDto.getType().equals(TransactionType.DEBIT) && account.getBalance() < transactionDto.getAmount()) {
			throw new Exception("Insufficient funds");
		}

		if (transactionDto.getType().equals(TransactionType.DEBIT)
				&& detectFraud(accountId, transactionDto.getAmount())) {
			throw new Exception("Fraud detection: Cannot withdraw more than $10,000 in a day");
		}

		TsfTransaction transaction = new TsfTransaction();
		transaction.setAccount(account);
		transaction.setAmount(transactionDto.getAmount());
		transaction.setType(transactionDto.getType());
		transaction.setTransactionDate(LocalDateTime.now());

		if (transactionDto.getType().equals(TransactionType.CREDIT)) {
			account.setBalance(account.getBalance() + transactionDto.getAmount());
		} else {
			account.setBalance(account.getBalance() - transactionDto.getAmount());
		}

		transactionRepository.save(transaction);
		accountService.saveAccount(account);
	}

	@Override
	public Page<TsfTransaction> getTransactionHistory(FilterCriteriaDto filterCriteriaDto) {
		if(filterCriteriaDto.getPage() == 0.0) {
			filterCriteriaDto.setPage(1);
		}
		
		if(filterCriteriaDto.getSize() == 0) {
			filterCriteriaDto.setSize(10);
		}
		
		Pageable pageable = PageRequest.of(filterCriteriaDto.getPage(), filterCriteriaDto.getSize());
		TransactionType trasactionType = TsfappEnums.TransactionType.valueOf(filterCriteriaDto.getType());
		
		// Fetch transactions based on the given filters
		if (!filterCriteriaDto.getType().isBlank() && filterCriteriaDto.getStartDate() != null
				&& filterCriteriaDto.getEndDate() != null) {
			return transactionRepository.findByAccountIdAndTypeAndTransactionDateBetweenPageable(
					filterCriteriaDto.getAccountId(), trasactionType, filterCriteriaDto.getStartDate(),
					filterCriteriaDto.getEndDate(), pageable);
		} else if (!filterCriteriaDto.getType().isBlank() && filterCriteriaDto.getAccountId() > 0.0) {
			return transactionRepository.findByAccountIdAndType(filterCriteriaDto.getAccountId(), trasactionType,
					pageable);
		} else if (filterCriteriaDto.getAccountId() > 0.0 && filterCriteriaDto.getStartDate() != null
				&& filterCriteriaDto.getEndDate() != null) {
			return transactionRepository.findByAccountIdAndTransactionDateBetween(filterCriteriaDto.getAccountId(),
					filterCriteriaDto.getStartDate(), filterCriteriaDto.getEndDate(), pageable);
		} else {
			return transactionRepository.findByAccountId(filterCriteriaDto.getAccountId(), pageable);
		}
	}

	public boolean detectFraud(Long accountId, Double transactionAmount) {
		LocalDate today = LocalDate.now();
		LocalDateTime startOfDay = today.atStartOfDay();
		LocalDateTime endOfDay = today.atTime(LocalTime.MAX);

		// Get OUT transactions for the account today
		List<TsfTransaction> todayTransactions = transactionRepository
				.findByAccountIdAndTypeAndTransactionDateBetween(accountId, TransactionType.DEBIT, startOfDay, endOfDay);

		// Calculate the total amount withdrawn today
		double totalWithdrawnToday = todayTransactions.stream().mapToDouble(TsfTransaction::getAmount).sum();

		// Add the new transaction amount
		totalWithdrawnToday += transactionAmount;

		// Check if the total exceeds $10,000
		return totalWithdrawnToday > 10000;
	}

	
}