package com.fin.tsfapp.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fin.tsfapp.entity.User;
import com.fin.tsfapp.repository.UserRepository;
import com.fin.tsfapp.service.UserDetailsService;

@Service
public class UserServiceImpl implements UserDetailsService {

	@Autowired
	UserRepository userRepository;

	@Override
	public User findByUserName(String userName) {
		return userRepository.findByUserName(userName);
	}

}
