package com.fin.tsfapp.dto;

public class ErrorDetails {
	private String exception;
	private int status;
	private String error;
	private String message;

	public ErrorDetails(String exception, int status, String error, String message) {
		super();
		this.exception = exception;
		this.status = status;
		this.error = error;
		this.message = message;
	}

	public ErrorDetails(String exception, int status, String error) {
		super();
		this.exception = exception;
		this.status = status;
		this.error = error;
	}

	public ErrorDetails(int status, String error) {
		super();
		this.status = status;
		this.error = error;
	}

	public ErrorDetails(int value, String error, String message) {
		this.status = value;
		this.error = error;
		this.message = message;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
}
